# AssetTrack - Assessment MVP

A full-stack asset management application for the assessment:
- Dashboard metrics and filters
- Purchases
- Transfers between bases
- Assets
- Simple role-based access
- Audit log
- React frontend
- Spring Boot REST backend
- MySQL schema

## Run

### Backend
1. Install Java 17+ and Maven.
2. Create a MySQL database named `assettrack`.
3. Update `backend/src/main/resources/application.properties` with your MySQL username/password.
4. Run:
   `cd backend`
   `mvn spring-boot:run`

### Frontend
1. Install Node.js.
2. Run:
   `cd frontend`
   `npm install`
   `npm run dev`

Open the Vite URL shown in the terminal.

Demo login:
- admin / admin
- commander / commander
- logistics / logistics

This is an assessment-ready MVP. Add more validation/security before production use.
